package com.gamebooster.pro

import android.content.Context
import android.os.Build
import android.view.Display
import android.view.WindowManager

object DeviceInfo {
    data class Snapshot(val model: String, val android: String, val refreshHz: Float, val resolution: String)

    @Suppress("DEPRECATION")
    fun read(context: Context): Snapshot {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display = if (Build.VERSION.SDK_INT >= 30) context.display else wm.defaultDisplay
        val mode = display?.mode
        val metrics = android.util.DisplayMetrics()
        display?.getRealMetrics(metrics)
        return Snapshot(
            model = "${Build.MANUFACTURER} ${Build.MODEL}".trim(),
            android = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            refreshHz = mode?.refreshRate ?: 60f,
            resolution = "${metrics.widthPixels} × ${metrics.heightPixels}"
        )
    }
}
