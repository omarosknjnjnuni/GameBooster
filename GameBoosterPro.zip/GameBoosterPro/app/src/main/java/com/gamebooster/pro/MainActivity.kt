package com.gamebooster.pro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090D16)
private val Panel = Color(0xFF141C2B)
private val Cyan = Color(0xFF42E8F5)
private val Muted = Color(0xFF9AA8BD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val device = DeviceInfo.read(this)
        setContent { GameBoosterScreen(device) }
    }
}

@Composable
private fun GameBoosterScreen(device: DeviceInfo.Snapshot) {
    var selectedTab by remember { mutableStateOf(0) }
    var showInfo by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, background = Bg, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Bg) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(14.dp), color = Cyan.copy(alpha = .13f), modifier = Modifier.size(48.dp)) {
                        Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Bolt, null, tint = Cyan, modifier = Modifier.size(30.dp)) }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("GAME BOOSTER", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
                        Text("PRO CONTROL CENTER", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    Surface(color = Color(0xFF173B3E), shape = RoundedCornerShape(50)) {
                        Text("READY", color = Cyan, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(26.dp))
                Text("DEVICE OVERVIEW", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(10.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(device.model, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(device.android, color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(18.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Metric("DISPLAY", device.resolution, Modifier.weight(1f))
                            Metric("REFRESH RATE", "${device.refreshHz.toInt()} Hz", Modifier.weight(1f))
                        }
                    }
                }
                Spacer(Modifier.height(22.dp))
                Text("PERFORMANCE TOOLS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(10.dp))
                ToolCard(Icons.Default.Speed, "Refresh rate", "Shows the display mode currently reported by Android.", "DISPLAY INFO")
                ToolCard(Icons.Default.Memory, "System tuning", "Safe controls are prepared for authorized Shizuku integration.", "COMING NEXT")
                ToolCard(Icons.Default.Bolt, "Game profile", "Per-game profiles without changing game identity or bypassing protections.", "COMING NEXT")
                Spacer(Modifier.height(18.dp))
                OutlinedButton(onClick = { showInfo = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) {
                    Text("ABOUT PERFORMANCE READINGS")
                }
                Spacer(Modifier.height(12.dp))
                Text("Note: Android does not expose a universal real-time game FPS counter to ordinary apps. FPS/frametime monitoring requires supported system access and device-specific validation.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                Spacer(Modifier.height(24.dp))
                Text("GAME BOOSTER PRO • v1.0.0", color = Color(0xFF59677D), fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
        if (showInfo) AlertDialog(
            onDismissRequest = { showInfo = false },
            title = { Text("Accurate readings") },
            text = { Text("Refresh rate is the display mode reported by Android, not proof that a game is rendering at the same FPS. Unsupported FPS unlocks and fake device identity are intentionally not used." ) },
            confirmButton = { TextButton(onClick = { showInfo = false }) { Text("GOT IT") } },
            containerColor = Panel, titleContentColor = Color.White, textContentColor = Muted
        )
    }
}

@Composable
private fun Metric(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Color(0xFF0D1421), RoundedCornerShape(13.dp)).padding(12.dp)) {
        Text(label, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text(value, color = Cyan, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ToolCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, detail: String, tag: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(detail, color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
            }
            Text(tag, color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}
