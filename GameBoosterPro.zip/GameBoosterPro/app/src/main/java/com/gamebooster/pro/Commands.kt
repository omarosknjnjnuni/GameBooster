package com.gamebooster.pro

/** Validated command builders. These commands are intended for an explicitly authorized
 * Shizuku/shell session; never pass arbitrary user-provided shell text to exec(). */
object Commands {
    private val packageName = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+$")
    private val rate = Regex("^\\d{1,3}(\\.\\d{1,2})?$")
    private val density = 120..800
    private val dimension = 320..4000

    enum class Setting(val namespace: String, val key: String, val validator: Regex) {
        PEAK_REFRESH("system", "peak_refresh_rate", rate),
        MIN_REFRESH("system", "min_refresh_rate", rate),
        WINDOW_ANIMATION("global", "window_animation_scale", Regex("^[0-5](\\.\\d{1,2})?$")),
        TRANSITION_ANIMATION("global", "transition_animation_scale", Regex("^[0-5](\\.\\d{1,2})?$")),
        ANIMATOR_DURATION("global", "animator_duration_scale", Regex("^[0-5](\\.\\d{1,2})?$"))
    }

    fun read(setting: Setting) = "settings get ${setting.namespace} ${setting.key}"
    fun reset(setting: Setting) = "settings delete ${setting.namespace} ${setting.key}"
    fun write(setting: Setting, value: String): String {
        require(setting.validator.matches(value)) { "Invalid value" }
        return "settings put ${setting.namespace} ${setting.key} $value"
    }
    fun setResolution(width: Int, height: Int): String {
        require(width in dimension && height in dimension) { "Resolution out of range" }
        return "wm size ${width}x$height"
    }
    fun resetResolution() = "wm size reset"
    fun setDensity(dpi: Int): String {
        require(dpi in density) { "DPI out of range" }
        return "wm density $dpi"
    }
    fun resetDensity() = "wm density reset"
    fun gameMode(pkg: String, mode: String): String {
        require(packageName.matches(pkg)) { "Invalid package name" }
        require(mode in setOf("standard", "performance", "battery")) { "Invalid game mode" }
        return "cmd game mode $mode $pkg"
    }
}
