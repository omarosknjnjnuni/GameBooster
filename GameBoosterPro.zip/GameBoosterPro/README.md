# Game Booster Pro

Android starter project using Kotlin, Jetpack Compose, and validated command builders for a future explicitly authorized Shizuku integration.

## Build an APK on GitHub

1. Create a GitHub repository.
2. Upload the contents of this folder to the repository root (not the containing folder).
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Android APK** with **Run workflow**, or push to `main` / `master`.
5. Open the completed workflow run and download the `GameBoosterPro-debug-apk` artifact.

## Build locally

Requires JDK 17, Android SDK platform 35, and Gradle 8.7:

```bash
gradle --no-daemon :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations

- This initial build is a functional UI/device-information foundation, not a finished performance engine.
- Display refresh rate is not the same thing as in-game FPS.
- FPS/frametime, GPU utilization, thermal readings, and privileged tuning vary by Android version and device vendor. They must be implemented and validated per device; this project does not fabricate readings.
- The command builders validate values, but no arbitrary shell execution interface is exposed in the UI.
- No game identity spoofing, anti-cheat bypass, or unsupported FPS unlocking is included.
